package com.example.clase22a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase22aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase22aApplication.class, args);
	}

}
